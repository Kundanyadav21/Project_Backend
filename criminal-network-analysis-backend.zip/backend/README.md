# AI-Powered Criminal Network Analysis System — Backend

A SQLite-backed FastAPI + SQLAlchemy 2.x backend for a law-enforcement-style
analytical application: investigation (case) management, network/relationship
analysis, evidence metadata management, AI-assisted (decision-support-only)
analysis, reports with supervisor review, and role-based access control for
**Analyst** and **Supervisor** interfaces.

> **Data ethics note:** This system treats all person/organization/relationship
> records as *investigative data*, not proof of criminal activity. AI output is
> always stored as hedged, review-pending analytical assistance
> (`app/services/ai_analysis.py` enforces this in code, not just docs) and must
> be reviewed by a human before it can inform a report or a risk-level change.

---

## 1. Project structure

```
backend/
├── app/
│   ├── __init__.py
│   ├── main.py                 # FastAPI app, router mounting, startup init
│   ├── database.py             # engine, session factory, get_db(), init_db()
│   ├── models.py                # SQLAlchemy 2.x declarative models
│   ├── schemas.py                # Pydantic request/response schemas
│   ├── security.py               # password hashing + JWT auth dependencies
│   ├── audit.py                   # shared audit-log helper
│   ├── routers/
│   │   ├── auth.py               # POST /auth/login
│   │   ├── analyst.py            # /analyst/*, /ai/analyze
│   │   ├── supervisor.py         # /supervisor/*
│   │   ├── cases.py              # /cases
│   │   ├── persons.py            # /persons
│   │   ├── evidence.py           # /evidence
│   │   ├── network.py            # /relationships, /cases/{id}/network*
│   │   └── reports.py            # /reports
│   └── services/
│       ├── ai_analysis.py        # enforces non-definitive AI phrasing
│       └── network_analysis.py   # centrality metrics (pure Python, no deps)
├── data/
│   └── criminal_network.db       # created automatically on first run
├── init_db.py                    # standalone: create tables
├── seed_data.py                  # standalone: insert fictional demo data
├── requirements.txt
└── README.md
```

---

## 2. Setup

```bash
cd backend
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 3. Create the database

The database is created automatically the first time the FastAPI app starts,
but you can also do it explicitly (idempotent — never drops existing data):

```bash
python init_db.py
```

This creates `data/criminal_network.db` with all 14 tables and enables
`PRAGMA foreign_keys=ON` for every connection.

## 4. Load fictional demo data (optional)

```bash
python seed_data.py
```

Creates 1 supervisor, 2 analysts, 1 sample case, 3 sample persons, 2 sample
relationships, 1 evidence-metadata record, 1 pending AI analysis, and sample
network metrics — **all explicitly labeled as fictional** in the
`description`/`input_description` fields. No real names, organizations, or
records are used. Demo login passwords are `ChangeMe123!` for every seeded
user — rotate these before any real deployment.

## 5. Run the API

```bash
uvicorn app.main:app --reload
```

Visit `http://127.0.0.1:8000/docs` for interactive Swagger UI (auto-generated
from the Pydantic schemas below), or `http://127.0.0.1:8000/health` for a
liveness check.

## 6. Inspect the database directly

```bash
sqlite3 data/criminal_network.db
sqlite> .tables
sqlite> .schema relationships
sqlite> SELECT * FROM users;
sqlite> PRAGMA foreign_key_check;   -- verify no orphaned foreign keys
```

Or with Python:

```python
from app.database import SessionLocal
from app.models import Case
db = SessionLocal()
print(db.query(Case).all())
```

## 7. Run tests / sanity checks

No test framework is bundled, but a quick end-to-end smoke test:

```bash
python init_db.py
python seed_data.py
uvicorn app.main:app --reload &

curl -s -X POST http://127.0.0.1:8000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "demo_analyst_1", "password": "ChangeMe123!"}'
# -> copy the access_token from the response

curl -s http://127.0.0.1:8000/cases \
  -H "Authorization: Bearer <access_token>"

curl -s http://127.0.0.1:8000/cases/1/network \
  -H "Authorization: Bearer <access_token>"
```

You can also exercise the pure-Python metric/AI-phrasing logic without any
database or web server at all:

```python
from app.services.network_analysis import compute_case_network_metrics
from app.services.ai_analysis import run_relationship_detection

print(compute_case_network_metrics([1, 2, 3], [(1, 2), (2, 3)]))
print(run_relationship_detection(["Demo Person A", "Demo Person B"]))
```

---

## 8. How the tables relate to each other

```
User ──creates/assigned──> Case ──has──> Person ──has──> Relationship (edges between Persons)
                             │              │
                             │              ├──> PersonOrganization ──> Organization
                             │              ├──> EvidencePerson ──> Evidence ──> Source
                             │              └──> NetworkAnalysis (per-person metrics)
                             │
                             ├──> Evidence
                             ├──> AIAnalysis (case-level findings, review_status)
                             ├──> Report ──reviewed by──> User (supervisor)
                             └──> CaseAssignment ──> User (analyst), assigned_by ──> User (supervisor)

AuditLog: generic (table_name, record_id) log referencing User.id, used to
reconstruct a case's full history by resolving every child record's ID that
belongs to that case (see routers/analyst.py::case_history).
```

Key foreign-key relationships:

- **cases.created_by / assigned_to** → `users.id`
- **persons.case_id**, **organizations.case_id**, **evidence.case_id**,
  **relationships.case_id**, **ai_analysis.case_id**,
  **network_analysis.case_id**, **reports.case_id**,
  **case_assignments.case_id** → `cases.id` (cascade-delete with the case)
- **relationships.source_person_id / target_person_id** → `persons.id`
  (a directed edge; queried as undirected for centrality purposes)
- **person_organization** and **evidence_person** are many-to-many join
  tables between persons↔organizations and evidence↔persons respectively
- **sources.id** is referenced by `person_organization.source_id` and
  `relationships.source_id` so every network edge or org affiliation is
  traceable to where it came from
- **audit_logs.user_id** → `users.id` (nullable, so a system-generated audit
  row is still valid even without a specific acting user)

All `confidence_score` / `reliability_score` columns carry a database-level
`CHECK` constraint enforcing `0.0 <= score <= 1.0` (or `NULL`), in addition to
the Pydantic-level validators in `schemas.py`.

---

## 9. How Analyst and Supervisor permissions work

Role-based access is enforced with two FastAPI dependencies in
`app/security.py`:

- `get_current_user` — decodes the JWT from `Authorization: Bearer <token>`
  and loads the `User` row; raises `401` if missing/invalid/inactive.
- `require_supervisor` / `require_role(*roles)` — wraps `get_current_user`
  and raises `403` unless the user's `role` matches.

Effective behavior:

| Action                                   | Analyst                          | Supervisor |
|-------------------------------------------|-----------------------------------|------------|
| View own/assigned cases (`GET /cases`)     | ✅ (auto-filtered to own cases)   | ✅ (sees all cases) |
| Create case, person, org, evidence, relationship | ✅ | ✅ |
| Run AI-assisted analysis (`POST /ai/analyze`) | ✅ | ✅ |
| Run/view network metrics                   | ✅ | ✅ |
| Create / submit report                     | ✅ (own reports only)             | ✅ |
| Approve/reject/request-revision on a report (`PUT /reports/{id}/review`) | ❌ 403 | ✅ |
| Assign a case to an analyst (`POST /supervisor/assign-case`) | ❌ 403 | ✅ |
| Review AI analysis (`PUT /supervisor/ai-analysis/{id}/review`) | ❌ 403 | ✅ |
| View audit logs (`GET /supervisor/audit-logs`) | ❌ 403 | ✅ |
| Create/manage users (`POST /supervisor/users`) | ❌ 403 | ✅ |
| Close a case (`PUT /supervisor/cases/{id}/close`) | ❌ 403 | ✅ |

Every state-changing endpoint calls `record_audit(...)` (see `app/audit.py`)
so supervisors can trace who changed what and when via
`GET /supervisor/audit-logs`.

---

## 10. Connecting to FastAPI (already wired up)

`app/main.py` already mounts every router and calls `init_db()` on startup.
To reuse these models/schemas in a different FastAPI app, import from
`app.database`, `app.models`, and `app.schemas` as shown throughout
`app/routers/*.py` — each router is a self-contained `APIRouter` you can
`include_router()` selectively.

---

## 11. Migrating to PostgreSQL later

The schema was written to make this a low-effort change:

1. Change `DATABASE_URL` (env var, read in `app/database.py`) to e.g.
   `postgresql+psycopg://user:pass@host:5432/criminal_network`.
2. Remove the SQLite-only `connect_args={"check_same_thread": False}` and the
   `_set_sqlite_pragma` event listener (or guard it, as already done, behind
   `DATABASE_URL.startswith("sqlite")`).
3. All column types (`String`, `Integer`, `Float`, `DateTime`, `Text`,
   `Enum`) map directly onto native PostgreSQL types. `CheckConstraint` and
   `UniqueConstraint` usages are portable as-is.
4. Optional: switch integer primary keys to PostgreSQL native `UUID` — the
   `uuid` string column already present on `users`/`cases`/`persons` gives you
   a stable external identifier either way, so this can be done later without
   an API-breaking change.

---

## 12. Security notes

- Passwords are hashed with bcrypt via `passlib` — never stored in plaintext.
- JWT tokens are signed with `SECRET_KEY` (set this via environment variable
  in any non-local deployment — the in-code fallback is for local dev only).
- SQLite foreign-key enforcement is turned on for every connection.
- Every table with a `confidence_score`/`reliability_score` column enforces
  the 0.0–1.0 range at the database level via `CHECK` constraints.
- `case_number`, `username`, and `email` all have `UNIQUE` constraints.
- All AI-generated text is passed through
  `services/ai_analysis.assert_safe_language()`, which raises
  `UnsafeAIOutputError` if it detects a definitive guilt/innocence claim
  (e.g. "is a criminal", "should be arrested") before it can ever be
  persisted.
