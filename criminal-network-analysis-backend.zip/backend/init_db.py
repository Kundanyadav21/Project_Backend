"""
init_db.py

Standalone script: creates data/criminal_network.db and all tables if they
do not already exist. Safe to run repeatedly -- never drops existing data.

Usage:
    cd backend
    python init_db.py
"""

from app.database import DB_PATH, init_db


def main() -> None:
    print(f"Initializing database at: {DB_PATH}")
    init_db()
    print("Done. All tables created (existing data, if any, was preserved).")


if __name__ == "__main__":
    main()
