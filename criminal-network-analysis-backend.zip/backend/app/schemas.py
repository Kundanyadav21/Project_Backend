"""
schemas.py

Pydantic v2 schemas used by the FastAPI routers for request validation and
response serialization. These mirror models.py but keep API contracts
decoupled from ORM internals (e.g. no password_hash is ever returned).
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from .models import (
    AIAnalysisType,
    AssignmentStatus,
    AuditAction,
    CasePriority,
    CaseStatus,
    EvidenceType,
    IntegrityStatus,
    OrganizationType,
    RelationshipType,
    ReportStatus,
    ReviewStatus,
    RiskLevel,
    SourceType,
    UserRole,
)


def _confidence_validator(v: Optional[float]) -> Optional[float]:
    if v is not None and not (0.0 <= v <= 1.0):
        raise ValueError("confidence_score must be between 0.0 and 1.0")
    return v


# ---------------------------------------------------------------------------
# Auth / Users
# ---------------------------------------------------------------------------

class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    email: EmailStr
    password: str = Field(min_length=8, description="Plaintext password; hashed before storage")
    full_name: str
    role: UserRole
    department: Optional[str] = None


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    uuid: str
    username: str
    email: EmailStr
    full_name: str
    role: UserRole
    department: Optional[str] = None
    is_active: bool
    created_at: datetime
    last_login: Optional[datetime] = None


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---------------------------------------------------------------------------
# Cases
# ---------------------------------------------------------------------------

class CaseCreate(BaseModel):
    case_number: str
    title: str
    description: Optional[str] = None
    priority: CasePriority = CasePriority.MEDIUM
    assigned_to: Optional[int] = None


class CaseUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[CaseStatus] = None
    priority: Optional[CasePriority] = None
    assigned_to: Optional[int] = None


class CaseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    uuid: str
    case_number: str
    title: str
    description: Optional[str] = None
    status: CaseStatus
    priority: CasePriority
    created_by: int
    assigned_to: Optional[int] = None
    created_at: datetime
    updated_at: datetime
    closed_at: Optional[datetime] = None


# ---------------------------------------------------------------------------
# Persons
# ---------------------------------------------------------------------------

class PersonCreate(BaseModel):
    case_id: int
    name: str
    alias: Optional[str] = None
    date_of_birth: Optional[datetime] = None
    gender: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    occupation: Optional[str] = None
    description: Optional[str] = None
    risk_level: RiskLevel = RiskLevel.UNKNOWN


class PersonOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    uuid: str
    case_id: int
    name: str
    alias: Optional[str] = None
    risk_level: RiskLevel
    created_at: datetime
    updated_at: datetime


# ---------------------------------------------------------------------------
# Organizations
# ---------------------------------------------------------------------------

class OrganizationCreate(BaseModel):
    case_id: int
    name: str
    alias: Optional[str] = None
    type: OrganizationType = OrganizationType.UNKNOWN
    description: Optional[str] = None


class OrganizationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    uuid: str
    case_id: int
    name: str
    type: OrganizationType
    created_at: datetime


# ---------------------------------------------------------------------------
# Relationships (network edges)
# ---------------------------------------------------------------------------

class RelationshipCreate(BaseModel):
    case_id: int
    source_person_id: int
    target_person_id: int
    relationship_type: RelationshipType
    description: Optional[str] = None
    strength: Optional[float] = None
    confidence_score: Optional[float] = None
    source_id: Optional[int] = None

    _validate_confidence = field_validator("confidence_score")(_confidence_validator)

    @field_validator("target_person_id")
    @classmethod
    def _no_self_link(cls, v: int, info):  # noqa: ANN001
        source = info.data.get("source_person_id")
        if source is not None and v == source:
            raise ValueError("source_person_id and target_person_id must differ")
        return v


class RelationshipOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    case_id: int
    source_person_id: int
    target_person_id: int
    relationship_type: RelationshipType
    strength: Optional[float] = None
    confidence_score: Optional[float] = None
    verified: bool
    created_at: datetime


class NetworkGraphNode(BaseModel):
    id: int
    name: str
    risk_level: RiskLevel


class NetworkGraphEdge(BaseModel):
    source: int
    target: int
    relationship_type: RelationshipType
    strength: Optional[float] = None
    confidence_score: Optional[float] = None
    verified: bool


class NetworkGraphOut(BaseModel):
    case_id: int
    nodes: list[NetworkGraphNode]
    edges: list[NetworkGraphEdge]


# ---------------------------------------------------------------------------
# Evidence
# ---------------------------------------------------------------------------

class EvidenceCreate(BaseModel):
    case_id: int
    evidence_type: EvidenceType
    title: str
    description: Optional[str] = None
    file_path: Optional[str] = None
    hash: Optional[str] = None
    source: Optional[str] = None
    collection_date: Optional[datetime] = None
    integrity_status: IntegrityStatus = IntegrityStatus.UNVERIFIED
    person_ids: list[int] = Field(default_factory=list)


class EvidenceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    uuid: str
    case_id: int
    evidence_type: EvidenceType
    title: str
    integrity_status: IntegrityStatus
    created_at: datetime


# ---------------------------------------------------------------------------
# Sources
# ---------------------------------------------------------------------------

class SourceCreate(BaseModel):
    source_type: SourceType
    source_name: str
    description: Optional[str] = None
    reliability_score: Optional[float] = None

    _validate_confidence = field_validator("reliability_score")(_confidence_validator)


class SourceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    source_type: SourceType
    source_name: str
    reliability_score: Optional[float] = None


# ---------------------------------------------------------------------------
# AI Analysis
# ---------------------------------------------------------------------------

class AIAnalysisRequest(BaseModel):
    """
    Input to POST /ai/analyze. `result` is NOT supplied by the client --
    it is generated by services/ai_analysis.py using safe, non-definitive
    phrasing, then persisted.
    """

    case_id: int
    analysis_type: AIAnalysisType
    input_description: Optional[str] = None
    target_person_ids: list[int] = Field(default_factory=list)


class AIAnalysisOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    case_id: int
    analysis_type: AIAnalysisType
    result: str
    confidence_score: Optional[float] = None
    model_name: Optional[str] = None
    review_status: ReviewStatus
    created_at: datetime


class AIAnalysisReview(BaseModel):
    review_status: ReviewStatus
    reviewer_notes: Optional[str] = None


# ---------------------------------------------------------------------------
# Network Analysis (metrics)
# ---------------------------------------------------------------------------

class NetworkAnalysisOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    case_id: int
    person_id: int
    degree_centrality: Optional[float] = None
    betweenness_centrality: Optional[float] = None
    closeness_centrality: Optional[float] = None
    network_score: Optional[float] = None
    detected_cluster: Optional[str] = None
    calculated_at: datetime


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------

class ReportCreate(BaseModel):
    case_id: int
    title: str
    content: str


class ReportReview(BaseModel):
    status: ReportStatus
    supervisor_comments: Optional[str] = None

    @field_validator("status")
    @classmethod
    def _must_be_review_outcome(cls, v: ReportStatus) -> ReportStatus:
        allowed = {ReportStatus.APPROVED, ReportStatus.REJECTED, ReportStatus.REVISION_REQUIRED}
        if v not in allowed:
            raise ValueError(f"status must be one of {[s.value for s in allowed]}")
        return v


class ReportOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    uuid: str
    case_id: int
    created_by: int
    title: str
    content: str
    status: ReportStatus
    supervisor_comments: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    reviewed_at: Optional[datetime] = None


# ---------------------------------------------------------------------------
# Audit logs
# ---------------------------------------------------------------------------

class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: Optional[int] = None
    action: AuditAction
    table_name: Optional[str] = None
    record_id: Optional[int] = None
    timestamp: datetime
    ip_address: Optional[str] = None


# ---------------------------------------------------------------------------
# Case assignments
# ---------------------------------------------------------------------------

class CaseAssignmentCreate(BaseModel):
    case_id: int
    analyst_id: int


class CaseAssignmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    case_id: int
    analyst_id: int
    assigned_by: int
    assigned_at: datetime
    status: AssignmentStatus
