"""
database.py

Central database configuration for the Criminal Network Analysis System.

Responsibilities:
- Build the SQLite connection URL (relative to this project, in ./data/)
- Create the SQLAlchemy engine with SQLite-appropriate settings
- Enforce SQLite foreign-key constraints (off by default in SQLite!)
- Provide a session factory and a FastAPI-style `get_db()` dependency
- Provide `init_db()` to create the `data/` directory and all tables

The engine is configured so that migrating to PostgreSQL later mostly means
changing DATABASE_URL and removing the SQLite-specific `connect_args` /
event listener below -- the models themselves use portable SQLAlchemy types.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Generator

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

# ---------------------------------------------------------------------------
# Paths & connection URL
# ---------------------------------------------------------------------------

# backend/
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "criminal_network.db"

# Allow overriding via environment variable so this can later point at
# PostgreSQL (e.g. postgresql+psycopg://user:pass@host/dbname) without any
# code changes elsewhere in the application.
DATABASE_URL = os.environ.get("DATABASE_URL", f"sqlite:///{DB_PATH.as_posix()}")

# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(
    DATABASE_URL,
    connect_args=connect_args,
    echo=False,
    future=True,
)


@event.listens_for(Engine, "connect")
def _set_sqlite_pragma(dbapi_connection, connection_record) -> None:  # noqa: ANN001
    """
    SQLite does not enforce FOREIGN KEY constraints unless explicitly told to.
    This listener runs on every new DBAPI connection and turns it on, plus a
    couple of safe pragmas that help with concurrent read/write behavior.
    """
    if DATABASE_URL.startswith("sqlite"):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.close()


# ---------------------------------------------------------------------------
# Session factory
# ---------------------------------------------------------------------------

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


class Base(DeclarativeBase):
    """Shared declarative base for all ORM models."""
    pass


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------

def get_db() -> Generator:
    """
    Yield a database session and guarantee it is closed afterward.
    Use as a FastAPI dependency: `db: Session = Depends(get_db)`.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------

def init_db() -> None:
    """
    Create the data/ directory (already done above) and all tables that do
    not yet exist. This is intentionally non-destructive: it never drops or
    truncates existing tables/data.
    """
    # Import here (not at module top) to avoid circular imports, since
    # models.py imports Base from this module.
    from . import models  # noqa: F401

    Base.metadata.create_all(bind=engine)
