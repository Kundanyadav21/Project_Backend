"""
models.py

SQLAlchemy 2.x declarative models for the Criminal Network Analysis System.

Design notes
------------
- Integer surrogate primary keys are used throughout (simple, fast, and
  index-friendly in SQLite). A `uuid` string column is also included on the
  handful of tables most likely to be referenced externally (users, cases,
  persons) so the system can expose stable external identifiers without
  leaking sequential integer IDs -- and so a future PostgreSQL migration
  could switch to native UUID primary keys with minimal churn.
- All enumerations use Python `enum.Enum` + SQLAlchemy `Enum`, which is
  stored as SQLite TEXT (with a CHECK constraint) and maps cleanly onto
  PostgreSQL's native ENUM type later.
- `created_at`/`updated_at` are added wherever the spec calls for
  traceability; `updated_at` auto-updates via `onupdate`.
- Confidence scores (0.0-1.0) are enforced with CHECK constraints at the
  database level in addition to any application-level (Pydantic) validation.
- Cascade behavior: child rows that only make sense in the context of a
  parent (e.g. persons/evidence/relationships within a case) cascade-delete
  with the parent. Pure reference/history rows (audit_logs) do not cascade
  away a user's history if the user row itself is later deactivated.

This file avoids all deprecated SQLAlchemy 1.x patterns (no `Column` used
directly for model attributes; everything uses `Mapped` / `mapped_column`).
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import List, Optional

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    Enum as SAEnum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class UserRole(str, enum.Enum):
    ANALYST = "ANALYST"
    SUPERVISOR = "SUPERVISOR"


class CaseStatus(str, enum.Enum):
    OPEN = "OPEN"
    UNDER_INVESTIGATION = "UNDER_INVESTIGATION"
    REVIEW = "REVIEW"
    CLOSED = "CLOSED"


class CasePriority(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class RiskLevel(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    UNKNOWN = "UNKNOWN"


class OrganizationType(str, enum.Enum):
    ORGANIZATION = "ORGANIZATION"
    GANG = "GANG"
    COMPANY = "COMPANY"
    ASSOCIATION = "ASSOCIATION"
    UNKNOWN = "UNKNOWN"


class RelationshipType(str, enum.Enum):
    ASSOCIATE = "ASSOCIATE"
    COMMUNICATION = "COMMUNICATION"
    FINANCIAL = "FINANCIAL"
    FAMILY = "FAMILY"
    BUSINESS = "BUSINESS"
    TRANSACTION = "TRANSACTION"
    LOCATION = "LOCATION"
    UNKNOWN = "UNKNOWN"


class EvidenceType(str, enum.Enum):
    DOCUMENT = "DOCUMENT"
    IMAGE = "IMAGE"
    VIDEO = "VIDEO"
    AUDIO = "AUDIO"
    TRANSACTION = "TRANSACTION"
    COMMUNICATION = "COMMUNICATION"
    OTHER = "OTHER"


class IntegrityStatus(str, enum.Enum):
    VERIFIED = "VERIFIED"
    UNVERIFIED = "UNVERIFIED"
    COMPROMISED = "COMPROMISED"


class SourceType(str, enum.Enum):
    EVIDENCE = "EVIDENCE"
    DATABASE = "DATABASE"
    ANALYST = "ANALYST"
    PUBLIC_RECORD = "PUBLIC_RECORD"
    AI_ANALYSIS = "AI_ANALYSIS"
    OTHER = "OTHER"


class AIAnalysisType(str, enum.Enum):
    NETWORK_ANALYSIS = "NETWORK_ANALYSIS"
    ENTITY_EXTRACTION = "ENTITY_EXTRACTION"
    RELATIONSHIP_DETECTION = "RELATIONSHIP_DETECTION"
    RISK_ANALYSIS = "RISK_ANALYSIS"
    PATTERN_DETECTION = "PATTERN_DETECTION"
    SUMMARY = "SUMMARY"


class ReviewStatus(str, enum.Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    NEEDS_REVIEW = "NEEDS_REVIEW"


class ReportStatus(str, enum.Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    REVISION_REQUIRED = "REVISION_REQUIRED"


class AuditAction(str, enum.Enum):
    LOGIN = "LOGIN"
    CREATE = "CREATE"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    VIEW = "VIEW"
    ANALYSIS = "ANALYSIS"
    REPORT_SUBMITTED = "REPORT_SUBMITTED"
    REPORT_APPROVED = "REPORT_APPROVED"
    REPORT_REJECTED = "REPORT_REJECTED"


class AssignmentStatus(str, enum.Enum):
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"


# A single reusable CHECK-constraint fragment for any "confidence_score"
# column across tables (0.0 - 1.0 inclusive, or NULL).
def confidence_check(column_name: str = "confidence_score") -> CheckConstraint:
    return CheckConstraint(
        f"{column_name} IS NULL OR ({column_name} >= 0.0 AND {column_name} <= 1.0)",
        name=f"ck_{column_name}_range",
    )


# ---------------------------------------------------------------------------
# users
# ---------------------------------------------------------------------------

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(36), unique=True, index=True, default=_uuid)

    username: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    role: Mapped[UserRole] = mapped_column(SAEnum(UserRole), nullable=False, index=True)
    department: Mapped[Optional[str]] = mapped_column(String(150), nullable=True)
    is_active: Mapped[bool] = mapped_column(default=True, nullable=False)

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )
    last_login: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Relationships
    created_cases: Mapped[List["Case"]] = relationship(
        back_populates="creator", foreign_keys="Case.created_by"
    )
    assigned_cases: Mapped[List["Case"]] = relationship(
        back_populates="assignee", foreign_keys="Case.assigned_to"
    )
    reports: Mapped[List["Report"]] = relationship(
        back_populates="author", foreign_keys="Report.created_by"
    )
    ai_analyses: Mapped[List["AIAnalysis"]] = relationship(
        back_populates="creator", foreign_keys="AIAnalysis.created_by"
    )
    audit_logs: Mapped[List["AuditLog"]] = relationship(back_populates="user")
    case_assignments_made: Mapped[List["CaseAssignment"]] = relationship(
        back_populates="assigned_by_user", foreign_keys="CaseAssignment.assigned_by"
    )
    case_assignments_received: Mapped[List["CaseAssignment"]] = relationship(
        back_populates="analyst", foreign_keys="CaseAssignment.analyst_id"
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<User {self.username} ({self.role})>"


# ---------------------------------------------------------------------------
# cases
# ---------------------------------------------------------------------------

class Case(Base):
    __tablename__ = "cases"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(36), unique=True, index=True, default=_uuid)

    case_number: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    status: Mapped[CaseStatus] = mapped_column(
        SAEnum(CaseStatus), default=CaseStatus.OPEN, nullable=False, index=True
    )
    priority: Mapped[CasePriority] = mapped_column(
        SAEnum(CasePriority), default=CasePriority.MEDIUM, nullable=False, index=True
    )

    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    assigned_to: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id"), nullable=True, index=True
    )

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Relationships
    creator: Mapped["User"] = relationship(back_populates="created_cases", foreign_keys=[created_by])
    assignee: Mapped[Optional["User"]] = relationship(
        back_populates="assigned_cases", foreign_keys=[assigned_to]
    )
    persons: Mapped[List["Person"]] = relationship(
        back_populates="case", cascade="all, delete-orphan"
    )
    organizations: Mapped[List["Organization"]] = relationship(
        back_populates="case", cascade="all, delete-orphan"
    )
    relationships_: Mapped[List["Relationship"]] = relationship(
        back_populates="case", cascade="all, delete-orphan"
    )
    evidence: Mapped[List["Evidence"]] = relationship(
        back_populates="case", cascade="all, delete-orphan"
    )
    ai_analyses: Mapped[List["AIAnalysis"]] = relationship(
        back_populates="case", cascade="all, delete-orphan"
    )
    network_analyses: Mapped[List["NetworkAnalysis"]] = relationship(
        back_populates="case", cascade="all, delete-orphan"
    )
    reports: Mapped[List["Report"]] = relationship(
        back_populates="case", cascade="all, delete-orphan"
    )
    assignments: Mapped[List["CaseAssignment"]] = relationship(
        back_populates="case", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Case {self.case_number} ({self.status})>"


# ---------------------------------------------------------------------------
# persons
# ---------------------------------------------------------------------------

class Person(Base):
    __tablename__ = "persons"
    __table_args__ = (
        Index("ix_persons_case_name", "case_id", "name"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(36), unique=True, index=True, default=_uuid)

    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    alias: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    date_of_birth: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    gender: Mapped[Optional[str]] = mapped_column(String(30), nullable=True)
    phone: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    address: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    occupation: Mapped[Optional[str]] = mapped_column(String(150), nullable=True)
    # Free-text investigative notes. Deliberately NOT a determination of guilt --
    # see risk_level docstring and AI-safety notes in services/ai_analysis.py.
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    risk_level: Mapped[RiskLevel] = mapped_column(
        SAEnum(RiskLevel), default=RiskLevel.UNKNOWN, nullable=False, index=True
    )

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    case: Mapped["Case"] = relationship(back_populates="persons")
    organization_links: Mapped[List["PersonOrganization"]] = relationship(
        back_populates="person", cascade="all, delete-orphan"
    )
    evidence_links: Mapped[List["EvidencePerson"]] = relationship(
        back_populates="person", cascade="all, delete-orphan"
    )
    network_analyses: Mapped[List["NetworkAnalysis"]] = relationship(
        back_populates="person", cascade="all, delete-orphan"
    )
    outgoing_relationships: Mapped[List["Relationship"]] = relationship(
        back_populates="source_person",
        foreign_keys="Relationship.source_person_id",
        cascade="all, delete-orphan",
    )
    incoming_relationships: Mapped[List["Relationship"]] = relationship(
        back_populates="target_person",
        foreign_keys="Relationship.target_person_id",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Person {self.name} risk={self.risk_level}>"


# ---------------------------------------------------------------------------
# organizations
# ---------------------------------------------------------------------------

class Organization(Base):
    __tablename__ = "organizations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(36), unique=True, index=True, default=_uuid)

    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    alias: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    type: Mapped[OrganizationType] = mapped_column(
        SAEnum(OrganizationType), default=OrganizationType.UNKNOWN, nullable=False
    )
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    case: Mapped["Case"] = relationship(back_populates="organizations")
    person_links: Mapped[List["PersonOrganization"]] = relationship(
        back_populates="organization", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Organization {self.name} ({self.type})>"


# ---------------------------------------------------------------------------
# person_organization (many-to-many)
# ---------------------------------------------------------------------------

class PersonOrganization(Base):
    __tablename__ = "person_organization"
    __table_args__ = (
        confidence_check(),
        UniqueConstraint("person_id", "organization_id", "role", name="uq_person_org_role"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    person_id: Mapped[int] = mapped_column(ForeignKey("persons.id"), nullable=False, index=True)
    organization_id: Mapped[int] = mapped_column(
        ForeignKey("organizations.id"), nullable=False, index=True
    )
    role: Mapped[Optional[str]] = mapped_column(String(150), nullable=True)
    start_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    end_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    confidence_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    source_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sources.id"), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    person: Mapped["Person"] = relationship(back_populates="organization_links")
    organization: Mapped["Organization"] = relationship(back_populates="person_links")
    source: Mapped[Optional["Source"]] = relationship()


# ---------------------------------------------------------------------------
# relationships  (the core network-analysis table)
# ---------------------------------------------------------------------------

class Relationship(Base):
    """
    Directed edge between two persons within a case. `strength` is a
    free-form analyst-assigned weight (e.g. 1-10); `confidence_score` is a
    0.0-1.0 probability-like value, typically populated by AI-assisted
    detection and always subject to `verified` sign-off by an analyst.
    """

    __tablename__ = "relationships"
    __table_args__ = (
        confidence_check(),
        CheckConstraint(
            "source_person_id != target_person_id", name="ck_relationship_no_self_link"
        ),
        Index("ix_relationships_case_type", "case_id", "relationship_type"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"), nullable=False, index=True)
    source_person_id: Mapped[int] = mapped_column(
        ForeignKey("persons.id"), nullable=False, index=True
    )
    target_person_id: Mapped[int] = mapped_column(
        ForeignKey("persons.id"), nullable=False, index=True
    )
    relationship_type: Mapped[RelationshipType] = mapped_column(
        SAEnum(RelationshipType), nullable=False, index=True
    )
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    strength: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    confidence_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    source_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sources.id"), nullable=True)
    # An analyst must confirm AI-suggested or informant-suggested edges before
    # they are treated as reliable for reporting purposes.
    verified: Mapped[bool] = mapped_column(default=False, nullable=False)
    created_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    case: Mapped["Case"] = relationship(back_populates="relationships_")
    source_person: Mapped["Person"] = relationship(
        back_populates="outgoing_relationships", foreign_keys=[source_person_id]
    )
    target_person: Mapped["Person"] = relationship(
        back_populates="incoming_relationships", foreign_keys=[target_person_id]
    )
    source: Mapped[Optional["Source"]] = relationship()
    creator: Mapped[Optional["User"]] = relationship()

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"<Relationship {self.source_person_id}->{self.target_person_id} "
            f"({self.relationship_type})>"
        )


# ---------------------------------------------------------------------------
# evidence
# ---------------------------------------------------------------------------

class Evidence(Base):
    """
    Evidence METADATA and secure references only. Per the design brief,
    sensitive file contents are not stored in SQLite -- `file_path` should
    point at a secured object store / file server, and `hash` should hold a
    content hash (e.g. SHA-256) for integrity verification.
    """

    __tablename__ = "evidence"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(36), unique=True, index=True, default=_uuid)

    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"), nullable=False, index=True)
    evidence_type: Mapped[EvidenceType] = mapped_column(
        SAEnum(EvidenceType), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    file_path: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    hash: Mapped[Optional[str]] = mapped_column(String(128), nullable=True, index=True)
    source: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    collected_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    collection_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    integrity_status: Mapped[IntegrityStatus] = mapped_column(
        SAEnum(IntegrityStatus), default=IntegrityStatus.UNVERIFIED, nullable=False
    )

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    case: Mapped["Case"] = relationship(back_populates="evidence")
    collector: Mapped[Optional["User"]] = relationship()
    person_links: Mapped[List["EvidencePerson"]] = relationship(
        back_populates="evidence", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Evidence {self.title} ({self.evidence_type})>"


# ---------------------------------------------------------------------------
# evidence_person (many-to-many)
# ---------------------------------------------------------------------------

class EvidencePerson(Base):
    __tablename__ = "evidence_person"
    __table_args__ = (
        confidence_check(),
        UniqueConstraint("evidence_id", "person_id", name="uq_evidence_person"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    evidence_id: Mapped[int] = mapped_column(ForeignKey("evidence.id"), nullable=False, index=True)
    person_id: Mapped[int] = mapped_column(ForeignKey("persons.id"), nullable=False, index=True)
    relevance: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    confidence_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    evidence: Mapped["Evidence"] = relationship(back_populates="person_links")
    person: Mapped["Person"] = relationship(back_populates="evidence_links")


# ---------------------------------------------------------------------------
# sources
# ---------------------------------------------------------------------------

class Source(Base):
    """
    Provenance registry. Any relationship, org link, or AI finding that cites
    a `source_id` should be traceable back to one of these rows, satisfying
    the "every finding traceable to source" requirement.
    """

    __tablename__ = "sources"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source_type: Mapped[SourceType] = mapped_column(SAEnum(SourceType), nullable=False, index=True)
    source_name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    reliability_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    __table_args__ = (confidence_check("reliability_score"),)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Source {self.source_name} ({self.source_type})>"


# ---------------------------------------------------------------------------
# ai_analysis
# ---------------------------------------------------------------------------

class AIAnalysis(Base):
    """
    AI-generated analytical results.

    IMPORTANT (AI safety / accuracy requirement): `result` must always be
    phrased as analytical assistance -- e.g. "Potential relationship
    detected", "Pattern requires analyst review", "Network connection
    identified with confidence 0.78" -- and never as a definitive claim of
    guilt (see services/ai_analysis.py for enforced phrasing helpers).
    Every row must be reviewable (`review_status`) by a human analyst or
    supervisor before it can inform a report.
    """

    __tablename__ = "ai_analysis"
    __table_args__ = (confidence_check(),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"), nullable=False, index=True)
    analysis_type: Mapped[AIAnalysisType] = mapped_column(
        SAEnum(AIAnalysisType), nullable=False, index=True
    )
    input_description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    result: Mapped[str] = mapped_column(Text, nullable=False)
    confidence_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    model_name: Mapped[Optional[str]] = mapped_column(String(150), nullable=True)
    model_version: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    created_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    reviewed_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)
    review_status: Mapped[ReviewStatus] = mapped_column(
        SAEnum(ReviewStatus), default=ReviewStatus.PENDING, nullable=False, index=True
    )

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    case: Mapped["Case"] = relationship(back_populates="ai_analyses")
    creator: Mapped[Optional["User"]] = relationship(
        back_populates="ai_analyses", foreign_keys=[created_by]
    )
    reviewer: Mapped[Optional["User"]] = relationship(foreign_keys=[reviewed_by])

    def __repr__(self) -> str:  # pragma: no cover
        return f"<AIAnalysis {self.analysis_type} status={self.review_status}>"


# ---------------------------------------------------------------------------
# network_analysis
# ---------------------------------------------------------------------------

class NetworkAnalysis(Base):
    """
    Calculated graph-theory metrics for a person within a case's network.
    These are analytical indicators (e.g. for triage / prioritizing analyst
    attention), not proof of criminal conduct.
    """

    __tablename__ = "network_analysis"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"), nullable=False, index=True)
    person_id: Mapped[int] = mapped_column(ForeignKey("persons.id"), nullable=False, index=True)

    degree_centrality: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    betweenness_centrality: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    closeness_centrality: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    network_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    detected_cluster: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)

    calculated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    algorithm_version: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    case: Mapped["Case"] = relationship(back_populates="network_analyses")
    person: Mapped["Person"] = relationship(back_populates="network_analyses")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<NetworkAnalysis person={self.person_id} score={self.network_score}>"


# ---------------------------------------------------------------------------
# reports
# ---------------------------------------------------------------------------

class Report(Base):
    __tablename__ = "reports"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    uuid: Mapped[str] = mapped_column(String(36), unique=True, index=True, default=_uuid)

    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"), nullable=False, index=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[ReportStatus] = mapped_column(
        SAEnum(ReportStatus), default=ReportStatus.DRAFT, nullable=False, index=True
    )
    supervisor_comments: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    reviewed_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    case: Mapped["Case"] = relationship(back_populates="reports")
    author: Mapped["User"] = relationship(back_populates="reports", foreign_keys=[created_by])
    reviewer: Mapped[Optional["User"]] = relationship(foreign_keys=[reviewed_by])

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Report {self.title} status={self.status}>"


# ---------------------------------------------------------------------------
# audit_logs
# ---------------------------------------------------------------------------

class AuditLog(Base):
    __tablename__ = "audit_logs"
    __table_args__ = (
        Index("ix_audit_logs_table_record", "table_name", "record_id"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    action: Mapped[AuditAction] = mapped_column(SAEnum(AuditAction), nullable=False, index=True)
    table_name: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    record_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    old_value: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    new_value: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), index=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)

    user: Mapped[Optional["User"]] = relationship(back_populates="audit_logs")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<AuditLog {self.action} on {self.table_name}:{self.record_id}>"


# ---------------------------------------------------------------------------
# case_assignments
# ---------------------------------------------------------------------------

class CaseAssignment(Base):
    __tablename__ = "case_assignments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    case_id: Mapped[int] = mapped_column(ForeignKey("cases.id"), nullable=False, index=True)
    analyst_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    assigned_by: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    assigned_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    status: Mapped[AssignmentStatus] = mapped_column(
        SAEnum(AssignmentStatus), default=AssignmentStatus.ASSIGNED, nullable=False, index=True
    )

    case: Mapped["Case"] = relationship(back_populates="assignments")
    analyst: Mapped["User"] = relationship(
        back_populates="case_assignments_received", foreign_keys=[analyst_id]
    )
    assigned_by_user: Mapped["User"] = relationship(
        back_populates="case_assignments_made", foreign_keys=[assigned_by]
    )

    def __repr__(self) -> str:  # pragma: no cover
        return f"<CaseAssignment case={self.case_id} analyst={self.analyst_id} ({self.status})>"
