"""
routers/reports.py

GET  /reports
POST /reports
PUT  /reports/{report_id}/review   (supervisor-only)
POST /reports/{report_id}/submit   (analyst moves DRAFT -> SUBMITTED)
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..audit import record_audit
from ..database import get_db
from ..models import AuditAction, Case, Report, ReportStatus, User, UserRole
from ..schemas import ReportCreate, ReportOut, ReportReview
from ..security import get_current_user, require_supervisor

router = APIRouter(prefix="/reports", tags=["reports"])


@router.get("", response_model=List[ReportOut])
def list_reports(
    case_id: Optional[int] = Query(default=None),
    status_filter: Optional[ReportStatus] = Query(default=None, alias="status"),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> List[Report]:
    query = db.query(Report)
    if case_id is not None:
        query = query.filter(Report.case_id == case_id)
    if status_filter is not None:
        query = query.filter(Report.status == status_filter)
    if user.role == UserRole.ANALYST:
        query = query.filter(Report.created_by == user.id)
    return query.order_by(Report.created_at.desc()).all()


@router.post("", response_model=ReportOut, status_code=status.HTTP_201_CREATED)
def create_report(
    payload: ReportCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> Report:
    case = db.get(Case, payload.case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    report = Report(
        case_id=payload.case_id,
        created_by=user.id,
        title=payload.title,
        content=payload.content,
        status=ReportStatus.DRAFT,
    )
    db.add(report)
    db.commit()
    db.refresh(report)

    record_audit(
        db, user_id=user.id, action=AuditAction.CREATE, table_name="reports", record_id=report.id
    )
    return report


@router.post("/{report_id}/submit", response_model=ReportOut)
def submit_report(
    report_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> Report:
    report = db.get(Report, report_id)
    if report is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Report not found")
    if report.created_by != user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not your report")
    if report.status != ReportStatus.DRAFT:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Only DRAFT reports can be submitted"
        )

    report.status = ReportStatus.SUBMITTED
    db.commit()
    db.refresh(report)

    record_audit(
        db,
        user_id=user.id,
        action=AuditAction.REPORT_SUBMITTED,
        table_name="reports",
        record_id=report.id,
    )
    return report


@router.put("/{report_id}/review", response_model=ReportOut)
def review_report(
    report_id: int,
    payload: ReportReview,
    db: Session = Depends(get_db),
    supervisor: User = Depends(require_supervisor),
) -> Report:
    report = db.get(Report, report_id)
    if report is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Report not found")
    if report.status != ReportStatus.SUBMITTED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only SUBMITTED reports can be reviewed",
        )

    report.status = payload.status
    report.supervisor_comments = payload.supervisor_comments
    report.reviewed_by = supervisor.id
    report.reviewed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(report)

    audit_action = {
        ReportStatus.APPROVED: AuditAction.REPORT_APPROVED,
        ReportStatus.REJECTED: AuditAction.REPORT_REJECTED,
    }.get(payload.status, AuditAction.UPDATE)

    record_audit(
        db, user_id=supervisor.id, action=audit_action, table_name="reports", record_id=report.id
    )
    return report
