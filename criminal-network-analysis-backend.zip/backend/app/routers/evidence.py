"""
routers/evidence.py

POST /evidence

Stores evidence METADATA only (title, type, hash, secure file_path
reference, chain-of-custody fields). Actual file bytes belong in a secured
object store outside SQLite, per the design brief.
"""

from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..audit import record_audit
from ..database import get_db
from ..models import AuditAction, Case, Evidence, EvidencePerson, Person, User
from ..schemas import EvidenceCreate, EvidenceOut
from ..security import get_current_user

router = APIRouter(prefix="/evidence", tags=["evidence"])


@router.post("", response_model=EvidenceOut, status_code=status.HTTP_201_CREATED)
def create_evidence(
    payload: EvidenceCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> Evidence:
    case = db.get(Case, payload.case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    data = payload.model_dump(exclude={"person_ids"})
    evidence = Evidence(**data, collected_by=user.id)
    db.add(evidence)
    db.flush()  # obtain evidence.id before creating link rows

    for person_id in payload.person_ids:
        person = db.get(Person, person_id)
        if person is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=f"Person {person_id} not found"
            )
        db.add(EvidencePerson(evidence_id=evidence.id, person_id=person_id))

    db.commit()
    db.refresh(evidence)

    record_audit(
        db, user_id=user.id, action=AuditAction.CREATE, table_name="evidence", record_id=evidence.id
    )
    return evidence


@router.get("", response_model=List[EvidenceOut])
def list_evidence(
    case_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> List[Evidence]:
    return db.query(Evidence).filter(Evidence.case_id == case_id).all()
