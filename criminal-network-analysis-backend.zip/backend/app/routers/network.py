"""
routers/network.py

POST /relationships
GET  /cases/{case_id}/network
GET  /cases/{case_id}/network/metrics
"""

from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..audit import record_audit
from ..database import get_db
from ..models import (
    AuditAction,
    Case,
    NetworkAnalysis,
    Person,
    Relationship,
    User,
)
from ..schemas import (
    NetworkAnalysisOut,
    NetworkGraphEdge,
    NetworkGraphNode,
    NetworkGraphOut,
    RelationshipCreate,
    RelationshipOut,
)
from ..security import get_current_user
from ..services.network_analysis import compute_case_network_metrics

router = APIRouter(tags=["network"])


@router.post("/relationships", response_model=RelationshipOut, status_code=status.HTTP_201_CREATED)
def create_relationship(
    payload: RelationshipCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> Relationship:
    case = db.get(Case, payload.case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    for pid in (payload.source_person_id, payload.target_person_id):
        person = db.get(Person, pid)
        if person is None or person.case_id != payload.case_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Person {pid} does not belong to case {payload.case_id}",
            )

    relationship = Relationship(**payload.model_dump(), created_by=user.id)
    db.add(relationship)
    db.commit()
    db.refresh(relationship)

    record_audit(
        db,
        user_id=user.id,
        action=AuditAction.CREATE,
        table_name="relationships",
        record_id=relationship.id,
    )
    return relationship


@router.get("/cases/{case_id}/network", response_model=NetworkGraphOut)
def get_case_network(
    case_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> NetworkGraphOut:
    case = db.get(Case, case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    persons = db.query(Person).filter(Person.case_id == case_id).all()
    edges = db.query(Relationship).filter(Relationship.case_id == case_id).all()

    return NetworkGraphOut(
        case_id=case_id,
        nodes=[NetworkGraphNode(id=p.id, name=p.name, risk_level=p.risk_level) for p in persons],
        edges=[
            NetworkGraphEdge(
                source=e.source_person_id,
                target=e.target_person_id,
                relationship_type=e.relationship_type,
                strength=e.strength,
                confidence_score=e.confidence_score,
                verified=e.verified,
            )
            for e in edges
        ],
    )


@router.post("/cases/{case_id}/network/calculate", response_model=List[NetworkAnalysisOut])
def calculate_network_metrics(
    case_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> List[NetworkAnalysis]:
    """
    Recompute centrality metrics for every person in the case and persist a
    fresh `network_analysis` row for each (history is preserved -- old rows
    are not deleted, so `calculated_at` shows a metric timeline).
    """
    case = db.get(Case, case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    persons = db.query(Person).filter(Person.case_id == case_id).all()
    person_ids = [p.id for p in persons]
    edges = db.query(Relationship).filter(Relationship.case_id == case_id).all()
    edge_tuples = [(e.source_person_id, e.target_person_id) for e in edges]

    metrics = compute_case_network_metrics(person_ids, edge_tuples)

    rows: List[NetworkAnalysis] = []
    for m in metrics:
        row = NetworkAnalysis(
            case_id=case_id,
            person_id=m.person_id,
            degree_centrality=m.degree_centrality,
            betweenness_centrality=m.betweenness_centrality,
            closeness_centrality=m.closeness_centrality,
            network_score=m.network_score,
            detected_cluster=m.detected_cluster,
            algorithm_version="networkx-free-basic-1.0.0",
        )
        db.add(row)
        rows.append(row)

    db.commit()
    for row in rows:
        db.refresh(row)

    record_audit(
        db, user_id=user.id, action=AuditAction.ANALYSIS, table_name="network_analysis", record_id=case_id
    )
    return rows


@router.get("/cases/{case_id}/network/metrics", response_model=List[NetworkAnalysisOut])
def get_network_metrics(
    case_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> List[NetworkAnalysis]:
    return (
        db.query(NetworkAnalysis)
        .filter(NetworkAnalysis.case_id == case_id)
        .order_by(NetworkAnalysis.calculated_at.desc())
        .all()
    )
