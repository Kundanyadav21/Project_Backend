"""
routers/cases.py

GET  /cases
POST /cases
GET  /cases/{case_id}
"""

from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..audit import record_audit
from ..database import get_db
from ..models import AuditAction, Case, User, UserRole
from ..schemas import CaseCreate, CaseOut, CaseUpdate
from ..security import get_current_user

router = APIRouter(prefix="/cases", tags=["cases"])


@router.get("", response_model=List[CaseOut])
def list_cases(
    db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> List[Case]:
    """Analysts see only cases assigned to (or created by) them; supervisors see all."""
    query = db.query(Case)
    if user.role == UserRole.ANALYST:
        query = query.filter(
            (Case.assigned_to == user.id) | (Case.created_by == user.id)
        )
    return query.order_by(Case.created_at.desc()).all()


@router.post("", response_model=CaseOut, status_code=status.HTTP_201_CREATED)
def create_case(
    payload: CaseCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> Case:
    existing = db.query(Case).filter(Case.case_number == payload.case_number).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="case_number already exists")

    case = Case(
        case_number=payload.case_number,
        title=payload.title,
        description=payload.description,
        priority=payload.priority,
        created_by=user.id,
        assigned_to=payload.assigned_to,
    )
    db.add(case)
    db.commit()
    db.refresh(case)

    record_audit(
        db, user_id=user.id, action=AuditAction.CREATE, table_name="cases", record_id=case.id
    )
    return case


@router.get("/{case_id}", response_model=CaseOut)
def get_case(
    case_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> Case:
    case = db.get(Case, case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    if user.role == UserRole.ANALYST and user.id not in (case.assigned_to, case.created_by):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized for this case")

    record_audit(db, user_id=user.id, action=AuditAction.VIEW, table_name="cases", record_id=case.id)
    return case


@router.put("/{case_id}", response_model=CaseOut)
def update_case(
    case_id: int,
    payload: CaseUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> Case:
    case = db.get(Case, case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")
    if user.role == UserRole.ANALYST and user.id not in (case.assigned_to, case.created_by):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized for this case")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(case, field, value)
    db.commit()
    db.refresh(case)

    record_audit(db, user_id=user.id, action=AuditAction.UPDATE, table_name="cases", record_id=case.id)
    return case
