"""
routers/persons.py

GET  /persons?case_id=...
POST /persons

Note (data-ethics safeguard baked into behavior, not just docs): this router
never derives or writes a `risk_level` automatically from AI output. Risk
level is set explicitly by an analyst; AI-suggested risk signals are stored
separately in `ai_analysis` with review_status=PENDING and must be reviewed
before anyone acts on them.
"""

from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..audit import record_audit
from ..database import get_db
from ..models import AuditAction, Case, Person, User
from ..schemas import PersonCreate, PersonOut
from ..security import get_current_user

router = APIRouter(prefix="/persons", tags=["persons"])


@router.get("", response_model=List[PersonOut])
def list_persons(
    case_id: Optional[int] = Query(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> List[Person]:
    query = db.query(Person)
    if case_id is not None:
        query = query.filter(Person.case_id == case_id)
    return query.order_by(Person.name).all()


@router.post("", response_model=PersonOut, status_code=status.HTTP_201_CREATED)
def create_person(
    payload: PersonCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> Person:
    case = db.get(Case, payload.case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    person = Person(**payload.model_dump())
    db.add(person)
    db.commit()
    db.refresh(person)

    record_audit(
        db, user_id=user.id, action=AuditAction.CREATE, table_name="persons", record_id=person.id
    )
    return person


@router.get("/{person_id}", response_model=PersonOut)
def get_person(
    person_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> Person:
    person = db.get(Person, person_id)
    if person is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Person not found")
    return person
