"""
routers/supervisor.py

All endpoints here require the SUPERVISOR role (enforced via
`Depends(require_supervisor)`).

GET  /supervisor/audit-logs
POST /supervisor/assign-case
GET  /supervisor/network-summaries
GET  /supervisor/users
POST /supervisor/users
PUT  /supervisor/cases/{case_id}/close
PUT  /supervisor/ai-analysis/{analysis_id}/review
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..audit import record_audit
from ..database import get_db
from ..models import (
    AIAnalysis,
    AssignmentStatus,
    AuditAction,
    AuditLog,
    Case,
    CaseAssignment,
    CaseStatus,
    NetworkAnalysis,
    User,
)
from ..schemas import (
    AIAnalysisOut,
    AIAnalysisReview,
    AuditLogOut,
    CaseAssignmentCreate,
    CaseAssignmentOut,
    CaseOut,
    UserCreate,
    UserOut,
)
from ..security import hash_password, require_supervisor

router = APIRouter(prefix="/supervisor", tags=["supervisor"])


@router.get("/audit-logs", response_model=List[AuditLogOut])
def view_audit_logs(
    table_name: Optional[str] = Query(default=None),
    user_id: Optional[int] = Query(default=None),
    limit: int = Query(default=200, le=1000),
    db: Session = Depends(get_db),
    _supervisor: User = Depends(require_supervisor),
) -> List[AuditLog]:
    query = db.query(AuditLog)
    if table_name:
        query = query.filter(AuditLog.table_name == table_name)
    if user_id:
        query = query.filter(AuditLog.user_id == user_id)
    return query.order_by(AuditLog.timestamp.desc()).limit(limit).all()


@router.post("/assign-case", response_model=CaseAssignmentOut, status_code=status.HTTP_201_CREATED)
def assign_case(
    payload: CaseAssignmentCreate,
    db: Session = Depends(get_db),
    supervisor: User = Depends(require_supervisor),
) -> CaseAssignment:
    case = db.get(Case, payload.case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    analyst = db.get(User, payload.analyst_id)
    if analyst is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Analyst not found")

    case.assigned_to = payload.analyst_id
    if case.status == CaseStatus.OPEN:
        case.status = CaseStatus.UNDER_INVESTIGATION

    assignment = CaseAssignment(
        case_id=payload.case_id,
        analyst_id=payload.analyst_id,
        assigned_by=supervisor.id,
        status=AssignmentStatus.ASSIGNED,
    )
    db.add(assignment)
    db.commit()
    db.refresh(assignment)

    record_audit(
        db,
        user_id=supervisor.id,
        action=AuditAction.UPDATE,
        table_name="case_assignments",
        record_id=assignment.id,
        new_value=f"assigned case {case.id} to analyst {analyst.id}",
    )
    return assignment


@router.get("/network-summaries")
def network_summaries(
    db: Session = Depends(get_db), _supervisor: User = Depends(require_supervisor)
) -> List[dict]:
    """Per-case counts of tracked persons, edges, and latest metric calculation time."""
    cases = db.query(Case).all()
    summaries = []
    for case in cases:
        person_count = len(case.persons)
        edge_count = len(case.relationships_)
        latest = (
            db.query(NetworkAnalysis)
            .filter(NetworkAnalysis.case_id == case.id)
            .order_by(NetworkAnalysis.calculated_at.desc())
            .first()
        )
        summaries.append(
            {
                "case_id": case.id,
                "case_number": case.case_number,
                "person_count": person_count,
                "relationship_count": edge_count,
                "last_calculated_at": latest.calculated_at if latest else None,
            }
        )
    return summaries


@router.get("/users", response_model=List[UserOut])
def list_users(
    db: Session = Depends(get_db), _supervisor: User = Depends(require_supervisor)
) -> List[User]:
    return db.query(User).order_by(User.username).all()


@router.post("/users", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(
    payload: UserCreate,
    db: Session = Depends(get_db),
    supervisor: User = Depends(require_supervisor),
) -> User:
    if db.query(User).filter(User.username == payload.username).first():
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="username already exists")
    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="email already exists")

    user = User(
        username=payload.username,
        email=payload.email,
        password_hash=hash_password(payload.password),
        full_name=payload.full_name,
        role=payload.role,
        department=payload.department,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    record_audit(
        db, user_id=supervisor.id, action=AuditAction.CREATE, table_name="users", record_id=user.id
    )
    return user


@router.put("/cases/{case_id}/close", response_model=CaseOut)
def close_case(
    case_id: int, db: Session = Depends(get_db), supervisor: User = Depends(require_supervisor)
) -> Case:
    case = db.get(Case, case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    case.status = CaseStatus.CLOSED
    case.closed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(case)

    record_audit(
        db, user_id=supervisor.id, action=AuditAction.UPDATE, table_name="cases", record_id=case.id
    )
    return case


@router.put("/ai-analysis/{analysis_id}/review", response_model=AIAnalysisOut)
def review_ai_analysis(
    analysis_id: int,
    payload: AIAnalysisReview,
    db: Session = Depends(get_db),
    supervisor: User = Depends(require_supervisor),
) -> AIAnalysis:
    analysis = db.get(AIAnalysis, analysis_id)
    if analysis is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="AI analysis not found")

    analysis.review_status = payload.review_status
    analysis.reviewed_by = supervisor.id
    analysis.reviewed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(analysis)

    record_audit(
        db,
        user_id=supervisor.id,
        action=AuditAction.UPDATE,
        table_name="ai_analysis",
        record_id=analysis.id,
        new_value=payload.review_status.value,
    )
    return analysis
