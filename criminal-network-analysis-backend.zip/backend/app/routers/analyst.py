"""
routers/analyst.py

GET  /analyst/cases            - cases assigned to (or created by) the current analyst
GET  /analyst/cases/{id}/history - audit trail for a specific case
POST /ai/analyze               - request AI-assisted analysis (decision support only)
GET  /ai/analyze/{id}          - fetch a specific AI analysis result
"""

from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..audit import record_audit
from ..database import get_db
from ..models import (
    AIAnalysis,
    AIAnalysisType,
    AuditAction,
    AuditLog,
    Case,
    Person,
    Relationship,
    ReviewStatus,
    User,
    UserRole,
)
from ..schemas import AIAnalysisOut, AIAnalysisRequest, AuditLogOut, CaseOut
from ..security import get_current_user
from ..services import ai_analysis

router = APIRouter(tags=["analyst"])


@router.get("/analyst/cases", response_model=List[CaseOut])
def my_cases(db: Session = Depends(get_db), user: User = Depends(get_current_user)) -> List[Case]:
    return (
        db.query(Case)
        .filter((Case.assigned_to == user.id) | (Case.created_by == user.id))
        .order_by(Case.created_at.desc())
        .all()
    )


@router.get("/analyst/cases/{case_id}/history", response_model=List[AuditLogOut])
def case_history(
    case_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> List[AuditLog]:
    case = db.get(Case, case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")
    if user.role == UserRole.ANALYST and user.id not in (case.assigned_to, case.created_by):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized for this case")

    # audit_logs is a generic (table_name, record_id) log, not case-scoped, so
    # we resolve every record_id that actually belongs to this case (across
    # every entity table) and match audit rows against that combined set.
    person_ids = [p.id for p in db.query(Person.id).filter(Person.case_id == case_id).all()]
    relationship_ids = [
        r.id for r in db.query(Relationship.id).filter(Relationship.case_id == case_id).all()
    ]
    from ..models import Evidence, Report  # local import: avoids polluting module-level namespace

    evidence_ids = [e.id for e in db.query(Evidence.id).filter(Evidence.case_id == case_id).all()]
    report_ids = [r.id for r in db.query(Report.id).filter(Report.case_id == case_id).all()]

    id_sets_by_table = {
        "cases": [case_id],
        "persons": person_ids,
        "relationships": relationship_ids,
        "evidence": evidence_ids,
        "reports": report_ids,
    }

    conditions = [
        (AuditLog.table_name == table) & (AuditLog.record_id.in_(ids))
        for table, ids in id_sets_by_table.items()
        if ids
    ]
    if not conditions:
        return []

    combined = conditions[0]
    for cond in conditions[1:]:
        combined = combined | cond

    return db.query(AuditLog).filter(combined).order_by(AuditLog.timestamp.desc()).all()


@router.post("/ai/analyze", response_model=AIAnalysisOut, status_code=status.HTTP_201_CREATED)
def request_ai_analysis(
    payload: AIAnalysisRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> AIAnalysis:
    """
    Runs the requested analysis type through services/ai_analysis.py, which
    guarantees non-definitive, review-oriented phrasing, then persists the
    result with review_status=PENDING. A supervisor or analyst must
    explicitly move it to APPROVED/REJECTED/NEEDS_REVIEW before its findings
    can be cited in a report.
    """
    case = db.get(Case, payload.case_id)
    if case is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Case not found")

    persons = []
    if payload.target_person_ids:
        persons = db.query(Person).filter(Person.id.in_(payload.target_person_ids)).all()

    if payload.analysis_type == AIAnalysisType.RELATIONSHIP_DETECTION:
        result = ai_analysis.run_relationship_detection(
            (p.name for p in persons), payload.input_description
        )
    elif payload.analysis_type == AIAnalysisType.ENTITY_EXTRACTION:
        result = ai_analysis.run_entity_extraction(payload.input_description)
    elif payload.analysis_type == AIAnalysisType.RISK_ANALYSIS:
        target_name = persons[0].name if persons else "unspecified individual"
        result = ai_analysis.run_risk_analysis(target_name, factor_count=max(len(persons), 1))
    elif payload.analysis_type == AIAnalysisType.PATTERN_DETECTION:
        edge_count = db.query(Relationship).filter(Relationship.case_id == payload.case_id).count()
        result = ai_analysis.run_pattern_detection(case.title, edge_count)
    elif payload.analysis_type == AIAnalysisType.NETWORK_ANALYSIS:
        node_count = db.query(Person).filter(Person.case_id == payload.case_id).count()
        edge_count = db.query(Relationship).filter(Relationship.case_id == payload.case_id).count()
        result = ai_analysis.run_network_analysis_summary(node_count, edge_count)
    else:  # SUMMARY
        item_count = db.query(Person).filter(Person.case_id == payload.case_id).count()
        result = ai_analysis.run_summary(case.title, item_count)

    analysis = AIAnalysis(
        case_id=payload.case_id,
        analysis_type=payload.analysis_type,
        input_description=payload.input_description,
        result=result.result_text,
        confidence_score=result.confidence_score,
        model_name=result.model_name,
        model_version=result.model_version,
        created_by=user.id,
        review_status=ReviewStatus.PENDING,
    )
    db.add(analysis)
    db.commit()
    db.refresh(analysis)

    record_audit(
        db, user_id=user.id, action=AuditAction.ANALYSIS, table_name="ai_analysis", record_id=analysis.id
    )
    return analysis


@router.get("/ai/analyze/{analysis_id}", response_model=AIAnalysisOut)
def get_ai_analysis(
    analysis_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> AIAnalysis:
    analysis = db.get(AIAnalysis, analysis_id)
    if analysis is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="AI analysis not found")
    return analysis
