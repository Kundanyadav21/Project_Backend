"""
services/network_analysis.py

Graph-metric computation over a case's `relationships` edges. Uses only the
standard library (no networkx dependency required, though the code is
structured so swapping in networkx later is a small, isolated change).

All metrics here are explicitly documented (and enforced via the AI-safety
service's phrasing) as analytical indicators for triage -- never a
determination of guilt.
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Dict, List, Tuple

ALGORITHM_VERSION = "networkx-free-basic-1.0.0"


@dataclass
class PersonMetrics:
    person_id: int
    degree_centrality: float
    betweenness_centrality: float
    closeness_centrality: float
    network_score: float
    detected_cluster: str


def _build_adjacency(
    person_ids: List[int], edges: List[Tuple[int, int]]
) -> Dict[int, set]:
    adjacency: Dict[int, set] = {pid: set() for pid in person_ids}
    for a, b in edges:
        adjacency.setdefault(a, set()).add(b)
        adjacency.setdefault(b, set()).add(a)
    return adjacency


def _connected_components(adjacency: Dict[int, set]) -> Dict[int, int]:
    """Return {person_id: cluster_index} via simple BFS."""
    cluster_of: Dict[int, int] = {}
    cluster_index = 0
    for node in adjacency:
        if node in cluster_of:
            continue
        queue = deque([node])
        cluster_of[node] = cluster_index
        while queue:
            current = queue.popleft()
            for neighbor in adjacency[current]:
                if neighbor not in cluster_of:
                    cluster_of[neighbor] = cluster_index
                    queue.append(neighbor)
        cluster_index += 1
    return cluster_of


def _bfs_shortest_paths(adjacency: Dict[int, set], start: int) -> Dict[int, int]:
    distances = {start: 0}
    queue = deque([start])
    while queue:
        current = queue.popleft()
        for neighbor in adjacency[current]:
            if neighbor not in distances:
                distances[neighbor] = distances[current] + 1
                queue.append(neighbor)
    return distances


def _betweenness_centrality_unweighted(adjacency: Dict[int, set]) -> Dict[int, float]:
    """
    Brandes' algorithm (unweighted), O(V*E) -- fine for investigation-scale
    networks (tens to low thousands of persons per case).
    """
    betweenness = {node: 0.0 for node in adjacency}
    nodes = list(adjacency.keys())

    for s in nodes:
        stack: List[int] = []
        predecessors: Dict[int, List[int]] = {node: [] for node in adjacency}
        sigma: Dict[int, int] = {node: 0 for node in adjacency}
        sigma[s] = 1
        distance: Dict[int, int] = {node: -1 for node in adjacency}
        distance[s] = 0
        queue = deque([s])

        while queue:
            v = queue.popleft()
            stack.append(v)
            for w in adjacency[v]:
                if distance[w] < 0:
                    distance[w] = distance[v] + 1
                    queue.append(w)
                if distance[w] == distance[v] + 1:
                    sigma[w] += sigma[v]
                    predecessors[w].append(v)

        delta: Dict[int, float] = {node: 0.0 for node in adjacency}
        while stack:
            w = stack.pop()
            for v in predecessors[w]:
                if sigma[w] > 0:
                    delta[v] += (sigma[v] / sigma[w]) * (1 + delta[w])
            if w != s:
                betweenness[w] += delta[w]

    # Undirected graph correction: each pair counted twice.
    n = len(nodes)
    scale = 1.0 / ((n - 1) * (n - 2)) if n > 2 else 0.0
    for node in betweenness:
        betweenness[node] = (betweenness[node] / 2.0) * scale if n > 2 else 0.0
    return betweenness


def compute_case_network_metrics(
    person_ids: List[int], edges: List[Tuple[int, int]]
) -> List[PersonMetrics]:
    """
    Compute degree/betweenness/closeness centrality and a simple connected-
    component "cluster" label for every person_id in a case's network.

    `edges` is a list of (source_person_id, target_person_id) tuples, already
    filtered to the case in question (treated as undirected for centrality
    purposes, consistent with typical criminal-network-analysis practice).
    """
    if not person_ids:
        return []

    adjacency = _build_adjacency(person_ids, edges)
    n = len(adjacency)
    cluster_of = _connected_components(adjacency)
    betweenness = _betweenness_centrality_unweighted(adjacency)

    results: List[PersonMetrics] = []
    for pid in person_ids:
        degree = len(adjacency.get(pid, set()))
        degree_centrality = degree / (n - 1) if n > 1 else 0.0

        distances = _bfs_shortest_paths(adjacency, pid)
        reachable = [d for node, d in distances.items() if node != pid and d > 0]
        if reachable:
            closeness = (len(reachable)) / sum(reachable) if sum(reachable) > 0 else 0.0
            # Normalize by fraction of graph reachable (Wasserman-Faust style)
            closeness *= len(reachable) / (n - 1) if n > 1 else 1.0
        else:
            closeness = 0.0

        b_score = betweenness.get(pid, 0.0)

        # Simple composite "network_score" for triage purposes only.
        network_score = round((degree_centrality + b_score + closeness) / 3, 4)

        results.append(
            PersonMetrics(
                person_id=pid,
                degree_centrality=round(degree_centrality, 4),
                betweenness_centrality=round(b_score, 4),
                closeness_centrality=round(closeness, 4),
                network_score=network_score,
                detected_cluster=f"cluster_{cluster_of.get(pid, 0)}",
            )
        )
    return results
