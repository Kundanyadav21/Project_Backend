"""
services/ai_analysis.py

This module is the single place where AI-generated analytical text is
produced. It exists to enforce, in code (not just documentation), the
AI-safety requirement from the spec:

    AI output must be stored as analytical assistance, not as a final
    determination of guilt or innocence. It must NOT make definitive claims
    such as "This person is a criminal." Instead it should use hedged,
    review-oriented language such as "Potential relationship detected" or
    "Pattern requires analyst review."

In a real deployment, `_call_model()` would invoke an actual ML/LLM model
(entity extraction, link prediction, clustering, etc.). Here it is a
deterministic stand-in so the schema and API are demonstrably runnable
without external dependencies -- swap it out for a real model call without
touching any other module.

Every function returns plain analytical text plus a confidence score; it is
the caller's (router's) job to persist this as an `AIAnalysis` row with
`review_status=PENDING`, so a human always reviews it before it can support
a report or a person's risk_level being changed.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Iterable, Optional

from ..models import AIAnalysisType

MODEL_NAME = "network-analysis-assist"
MODEL_VERSION = "0.1.0-demo"

# Banned phrases: definitive guilt/innocence claims. Used as a defensive
# post-generation check -- if a caller ever tries to persist text containing
# one of these, `assert_safe_language` raises rather than allowing the save.
_FORBIDDEN_PATTERNS = [
    "is a criminal",
    "is guilty",
    "committed the crime",
    "should be arrested",
    "is responsible for the crime",
    "confirmed criminal",
]


class UnsafeAIOutputError(ValueError):
    """Raised if generated or supplied AI text makes a definitive guilt claim."""


def assert_safe_language(text: str) -> None:
    lowered = text.lower()
    for phrase in _FORBIDDEN_PATTERNS:
        if phrase in lowered:
            raise UnsafeAIOutputError(
                f"AI analysis text contains a disallowed definitive claim: '{phrase}'. "
                "Rephrase as a hedged, review-oriented finding."
            )


@dataclass
class AIAnalysisResult:
    result_text: str
    confidence_score: float
    model_name: str = MODEL_NAME
    model_version: str = MODEL_VERSION


def _confidence_for(seed_len: int) -> float:
    # Deterministic-ish pseudo-confidence for demo purposes; a real model
    # would return a calibrated probability from its own inference.
    rng = random.Random(seed_len)
    return round(rng.uniform(0.55, 0.92), 2)


def run_relationship_detection(
    person_names: Iterable[str], input_description: Optional[str] = None
) -> AIAnalysisResult:
    names = list(person_names)
    confidence = _confidence_for(len(names) + len(input_description or ""))
    text = (
        f"Potential relationship detected among {len(names)} tracked individuals "
        f"based on available records. Network connection identified with confidence "
        f"{confidence:.2f}. Pattern requires analyst review before inclusion in a report."
    )
    assert_safe_language(text)
    return AIAnalysisResult(result_text=text, confidence_score=confidence)


def run_entity_extraction(input_description: Optional[str]) -> AIAnalysisResult:
    confidence = _confidence_for(len(input_description or "entity"))
    text = (
        "Candidate entities extracted from the supplied text for analyst review. "
        f"Extraction confidence {confidence:.2f}. No determination of involvement is implied; "
        "each entity should be independently corroborated."
    )
    assert_safe_language(text)
    return AIAnalysisResult(result_text=text, confidence_score=confidence)


def run_risk_analysis(person_name: str, factor_count: int) -> AIAnalysisResult:
    confidence = _confidence_for(len(person_name) + factor_count)
    text = (
        f"Risk indicator pattern flagged for review regarding one tracked individual, "
        f"based on {factor_count} contributing factor(s). Confidence {confidence:.2f}. "
        "This is an analytical prioritization signal only and is not a finding of wrongdoing; "
        "an analyst must review supporting evidence before any status change."
    )
    assert_safe_language(text)
    return AIAnalysisResult(result_text=text, confidence_score=confidence)


def run_pattern_detection(case_title: str, edge_count: int) -> AIAnalysisResult:
    confidence = _confidence_for(len(case_title) + edge_count)
    text = (
        f"A structural pattern across {edge_count} recorded connections requires analyst review. "
        f"Pattern-match confidence {confidence:.2f}. Presented as decision support only."
    )
    assert_safe_language(text)
    return AIAnalysisResult(result_text=text, confidence_score=confidence)


def run_summary(case_title: str, item_count: int) -> AIAnalysisResult:
    confidence = _confidence_for(len(case_title))
    text = (
        f"Draft analytical summary generated covering {item_count} case items for case "
        f"'{case_title}'. Confidence {confidence:.2f}. Intended as a starting point for "
        "analyst review and editing, not a final conclusion."
    )
    assert_safe_language(text)
    return AIAnalysisResult(result_text=text, confidence_score=confidence)


def run_network_analysis_summary(node_count: int, edge_count: int) -> AIAnalysisResult:
    confidence = _confidence_for(node_count + edge_count)
    text = (
        f"Network-level structure computed over {node_count} tracked individuals and "
        f"{edge_count} recorded connections. Confidence {confidence:.2f}. Centrality and "
        "cluster metrics are analytical indicators intended to help prioritize analyst "
        "attention, not evidence of criminal conduct."
    )
    assert_safe_language(text)
    return AIAnalysisResult(result_text=text, confidence_score=confidence)


_DISPATCH = {
    AIAnalysisType.RELATIONSHIP_DETECTION: run_relationship_detection,
    AIAnalysisType.ENTITY_EXTRACTION: run_entity_extraction,
    AIAnalysisType.RISK_ANALYSIS: run_risk_analysis,
    AIAnalysisType.PATTERN_DETECTION: run_pattern_detection,
    AIAnalysisType.SUMMARY: run_summary,
    AIAnalysisType.NETWORK_ANALYSIS: run_network_analysis_summary,
}
