"""
audit.py

Small helper so every router writes audit_logs consistently instead of
duplicating the same INSERT logic. Called after a successful commit so the
audit row reflects what actually persisted.
"""

from __future__ import annotations

from typing import Optional

from sqlalchemy.orm import Session

from .models import AuditAction, AuditLog


def record_audit(
    db: Session,
    *,
    user_id: Optional[int],
    action: AuditAction,
    table_name: Optional[str] = None,
    record_id: Optional[int] = None,
    old_value: Optional[str] = None,
    new_value: Optional[str] = None,
    ip_address: Optional[str] = None,
) -> AuditLog:
    entry = AuditLog(
        user_id=user_id,
        action=action,
        table_name=table_name,
        record_id=record_id,
        old_value=old_value,
        new_value=new_value,
        ip_address=ip_address,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry
