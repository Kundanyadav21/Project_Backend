"""AI-Powered Criminal Network Analysis System - backend application package."""
