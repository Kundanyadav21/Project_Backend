"""
main.py

FastAPI application entrypoint. Creates the database (non-destructively) on
startup and mounts all routers.

Run locally with:
    uvicorn app.main:app --reload
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import init_db
from .routers import analyst, auth, cases, evidence, network, persons, reports, supervisor

app = FastAPI(
    title="AI-Powered Criminal Network Analysis System",
    description=(
        "Investigation management, network/relationship analysis, evidence "
        "management, and AI-assisted (decision-support only) analysis for "
        "Analyst and Supervisor roles."
    ),
    version="1.0.0",
)

# Permissive CORS for local development; tighten origins for production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup() -> None:
    init_db()


@app.get("/health", tags=["health"])
def health_check() -> dict:
    return {"status": "ok"}


app.include_router(auth.router)
app.include_router(cases.router)
app.include_router(persons.router)
app.include_router(evidence.router)
app.include_router(network.router)
app.include_router(reports.router)
app.include_router(analyst.router)
app.include_router(supervisor.router)
